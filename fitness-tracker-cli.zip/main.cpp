
#include <iostream>
#include <string>
using namespace std;

class FitnessTracker {
private:
    int totalSteps;
    double totalCalories;
    int totalWorkouts;

public:
    FitnessTracker() : totalSteps(0), totalCalories(0.0), totalWorkouts(0) {}

    void logSteps(int steps) {
        totalSteps += steps;
        cout << "Added " << steps << " steps! Total steps: " << totalSteps << endl;
    }

    void logCalories(double calories) {
        totalCalories += calories;
        cout << "Added " << calories << " calories! Total calories: " << totalCalories << endl;
    }

    void logWorkout() {
        totalWorkouts++;
        cout << "Workout logged! Total workouts: " << totalWorkouts << endl;
    }

    void showSummary() const {
        cout << "\n--- Fitness Summary ---\n";
        cout << "Total Steps: " << totalSteps << endl;
        cout << "Total Calories: " << totalCalories << endl;
        cout << "Total Workouts: " << totalWorkouts << endl;
    }
};

int main() {
    FitnessTracker tracker;
    int choice;

    do {
        cout << "\n--- Fitness Tracker Menu ---\n";
        cout << "1. Log Steps\n";
        cout << "2. Log Calories\n";
        cout << "3. Log Workout\n";
        cout << "4. Show Summary\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int steps;
                cout << "Enter number of steps: ";
                cin >> steps;
                tracker.logSteps(steps);
                break;
            }
            case 2: {
                double calories;
                cout << "Enter calories burned: ";
                cin >> calories;
                tracker.logCalories(calories);
                break;
            }
            case 3:
                tracker.logWorkout();
                break;
            case 4:
                tracker.showSummary();
                break;
            case 5:
                cout << "Exiting... Stay fit!\n";
                break;
            default:
                cout << "Invalid choice, please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
