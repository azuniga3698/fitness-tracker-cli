
# Fitness Tracker CLI
A simple command-line C++ program for tracking workouts, calories, and steps.
Developed for the COSC 1437 final project.
